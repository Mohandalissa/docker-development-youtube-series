#!/bin/sh

videos $@