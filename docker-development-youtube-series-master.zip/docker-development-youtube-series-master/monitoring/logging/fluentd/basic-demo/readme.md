# Fluentd basic demo

Check out the [video](https://youtu.be/MMVdkzeQ848)
In my video: Introduction to logging <br/>
I run fluentd locally <br/>
I collect all local container logs into the `./logs` folder <br/>
Fluentd collects all the logs of the containers running on my machine.

```
docker-compose up
```