fluentd will collect all container logs and write them
in this folder