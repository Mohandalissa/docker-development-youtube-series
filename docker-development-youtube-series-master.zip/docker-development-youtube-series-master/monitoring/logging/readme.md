# Logging

## Logging Basics

* Standardised Logging
* Centralised Logging 

[Check it out](./fluentd/basic-demo/readme.md)

## Introduction to Fluentd

* What is fluentd
* Configuration
* Plugins
* Demos

[Check if out](./fluentd/introduction/readme.md)