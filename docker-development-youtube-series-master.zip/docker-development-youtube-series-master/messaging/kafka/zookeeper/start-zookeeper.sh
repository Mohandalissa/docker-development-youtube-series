#!/bin/bash -e

exec "/kafka/bin/zookeeper-server-start.sh" "/kafka/config/zookeeper.properties"