#!/bin/bash -e

exec "/kafka/bin/kafka-server-start.sh" "/kafka/config/server.properties"