# Kubernetes in the Cloud

## Introduction to Kubernetes on Cloud Providers

Microsoft Azure [here](./azure/getting-started.md) <br/>
Digital Ocean [here](./digitalocean/getting-started.md) <br/>
Linode Cloud [here](./linode/getting-started.md) <br/>
Amazon Web Services [here](./amazon/getting-started.md) <br/>
Google Cloud [here](./google/getting-started.md) <br/>